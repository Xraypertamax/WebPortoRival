let currentCertificateIndex = 0;
let currentProjectIndex = 0;

window.addEventListener('load', function() {
    const overlay = document.querySelector('.overlay');
    setTimeout(() => {
        overlay.style.opacity = '0'; // Mulai transisi fade-out
        setTimeout(() => {
            overlay.style.display = 'none'; // Sembunyikan overlay setelah transisi selesai
        }, 100); // Durasi animasi fade-out
    }, 3000); // Durasi animasi loading (3 detik)
});

function showSlide(sliderClass, slideIndex) {
    const slider = document.querySelector(sliderClass);
    const totalSlides = slider.querySelectorAll('.slide').length;

    if (slideIndex >= totalSlides) {
        slideIndex = 0;
    }
    if (slideIndex < 0) {
        slideIndex = totalSlides - 1;
    }

    slider.style.transform = `translateX(-${slideIndex * 100}%)`;

    return slideIndex;
}

function nextCertificate() {
    currentCertificateIndex++;
    currentCertificateIndex = showSlide('.slider-container.certificates .slider', currentCertificateIndex);
}

function prevCertificate() {
    currentCertificateIndex--;
    currentCertificateIndex = showSlide('.slider-container.certificates .slider', currentCertificateIndex);
}

function nextProject() {
    currentProjectIndex++;
    currentProjectIndex = showSlide('.slider-container.projects .slider', currentProjectIndex);
}

function prevProject() {
    currentProjectIndex--;
    currentProjectIndex = showSlide('.slider-container.projects .slider', currentProjectIndex);
}

document.addEventListener('DOMContentLoaded', function () {
    showSlide('.slider-container.certificates .slider', currentCertificateIndex);
    showSlide('.slider-container.projects .slider', currentProjectIndex);
});

